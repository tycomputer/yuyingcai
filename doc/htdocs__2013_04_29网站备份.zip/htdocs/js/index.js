var _newsHTML ="<ul>"
+"	<li><a href='news/kaihui1.html' target='_blank'>民盟北京市委调研</a></li>"
+"	<li><a href='news/huibao1.html' target='_blank'>口才与情商汇报演出</a></li>"
+"	<li><a href='news/fencai1.html' target='_blank'>课堂风采</a></li>"

+"</ul>"
+"<div align='right'><a href='news/list.html'>更多...</a></div>";
$(document).ready(function(){
	$("#newstd").html(_newsHTML);
});